<?php 
	include_once 'connection.php';

	if(isset($_POST['addCategory'])){
		$sql = "insert into categorymst (categoryname) values ('".$_POST['addCategory']."')";
		$result = $con->query($sql);
		echo 'Category added Successfully.';
	}

	if(isset($_POST['selectCategory']) && isset($_POST['updateCategory'])){
		$sql = "update categorymst set categoryname='".$_POST['updateCategory']."' where categoryid = ".$_POST['selectCategory'];
		$result = $con->query($sql);
		echo 'Category has updated Successfully.';
	}

	if(isset($_POST['deleteSelectCategory'])){
		$sql = "delete from categorymst where categoryid=".$_POST['deleteSelectCategory'];
		$result = $con->query($sql);
		echo 'Category has deleted Successfully.';	
	}

	if(isset($_POST['Upload'])){

	  $name = $_FILES['file']['name'];
	  $filename = substr($name, 0,strlen($name)-4);
	  $target_dir = "images/";
	  $target_file = $target_dir . basename($_FILES["file"]["name"]);

	  // Select file type
	  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	  // Valid file extensions
	  $extensions_arr = array("jpg","jpeg","png","gif","jfif");

	  // Check extension
	  if( in_array($imageFileType,$extensions_arr) ){
	 
	     // Insert record
	     $query = "insert into productmst(categoryid,productname,qty,description,price,imgname,imgfile) values(".$_POST['productAdd'].",'".$_POST['ProductName']."','".$_POST['ProductQuantity']."','".$_POST['ProductDescription']."',".$_POST['ProductPrice'].",'".$filename."','".$name."')";
	     mysqli_query($con,$query);
	  
	     // Upload file
	     move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
	  }
	  echo 'Product has been added Successfully.';
	}

	if(isset($_POST['UpdateProduct'])){

	  $name = $_FILES['updateFile']['name'];
	  $filename = substr($name, 0,strlen($name)-4);
	  $target_dir = "images/";
	  $target_file = $target_dir . basename($_FILES["updateFile"]["name"]);

	  // Select file type
	  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	  // Valid file extensions
	  $extensions_arr = array("jpg","jpeg","png","gif","jfif");

	  // Check extension
	  if( in_array($imageFileType,$extensions_arr) ){
	 	$sql = "update productmst set productname = '".$_POST['UpdateProductName']."',qty = '".$_POST['UpdateProductQuantity']."',price=".$_POST['UpdateProductPrice'].",description='".$_POST['UpdateProductDescription']."',imgname='".$filename."',imgfile='".$name."' where productid=".$_POST['productUpdate'] ;
	 	mysqli_query($con,$sql);		
	 		echo 'Product has updated Successfully.';
		}
	}

	if(isset($_POST['ProductDel'])){
		$sql = "delete from productmst where productid = ".$_POST['DeleteProduct'];
		mysqli_query($con,$sql);
		echo "Product has deleted Successfully.";
	}

	if(isset($_POST['DeleteCustomer'])){
		$sql = "delete from customermst where cid = ".$_POST['selectCustomer'];
		mysqli_query($con,$sql);
		echo "Customer Deleted Successfully.";	
	}

?>
