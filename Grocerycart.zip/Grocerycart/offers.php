
<!doctype html>
<?php 
 
    session_start();

    include_once 'connection.php';

    if($con != false){
        $arrProductData = getProductsData($con);
         
        //echo '<pre>';print_r($arrProductData);die;
    }

           

    function getProductsData($con){
        
       // $filename = basename($_SERVER['PHP_SELF']);
        //$category_name =substr($filename,0,strlen($filename)-4);
        $sqlQuery = 'select p.qty,p.imgname,p.productid,p.categoryid,p.productname, p.imgfile, p.price, o.discount from offers o inner join productmst p on o.productid = p.productid';
        $result = $con->query($sqlQuery);
        if($result->num_rows > 0){
            $arrProductData = array();
            while($row = $result->fetch_assoc()){
                $arrProductData [] = $row;
            }
            //echo '<pre>';print_r($arrHouseHoldData);die;

            if(is_array($arrProductData) && count($arrProductData) > 0){
                return $arrProductData;
            }
            else{
                return 0;
            }
        }
    }    

    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }
?>

<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Offers</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row{
            width: 100%;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>';
    ?>
    <section>
        <div class="row">
            <div class="d-flex justify-content-around flex-wrap">
                <?php
                            if($arrProductData != 0){
                                $newprice=0;
                                foreach ($arrProductData as $key => $arrOneRowData){
                                    $image_src = "images/".$arrOneRowData["imgfile"];
                                    $pid=$arrOneRowData["productid"];
                                    $cid=$arrOneRowData["categoryid"];
                                    $price=$arrOneRowData["price"];
                                    $discount=$arrOneRowData["discount"];
                                    $newprice=$price-($price*$discount)/100;
                                    echo '
                                        <div class="card m-3 shadow" style="width: 18rem;">
                                            <a href="ProductDescription.php?pid='.$pid.'&cid='.$cid.'" ><img src="'.$image_src.'" class="card-img-top" style="width:270px;height:220px" alt="'.$arrOneRowData["imgfile"].'">
                                            <div class="card-body" style="height:188px">
                                                <h5 class="card-title">'.$arrOneRowData["productname"].'</h5>
                                                <div class="d-flex justify-content-start">
                                                <p class="card-text">Rs<strike> '.$arrOneRowData["price"].'</strike></p>
                                                <p class="card-text">&nbsp,&nbsp&nbsp '.$arrOneRowData["discount"].'%&nbsp off</p>
                                                </div>
                                                <div class="d-flex justify-content-start">
                                                <p class="card-text">Rs '.$newprice.'&nbsp,&nbsp&nbsp</p>
                                                <p class="card-text">'.$arrOneRowData["qty"].'</p>
                                                </div>
                                            </div>
                                            </a>
                                            <a href="#" class="btn btn-primary" onclick="addToCart('.$pid.','.$cid.','.$IdOfCustomer.','.$newprice.',1)" >Add to cart</a>
                                        </div>';
                                }
                            }
                            
                        ?>
            </div>
        </div>
    </section>

    <footer class="container mt-3">
        <p class="float-right"><a href="#">Back to top</a></p>
        <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
    </footer>


    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <!--    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>-->
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script type="text/javascript">
        function addToCart(productId, cateogryId, customerId, price, quantity) {
            $.ajax({
                url: 'commonAjax.php?action=ADDTOCART',
                type: 'POST',
                data: {
                    productId: productId,
                    categoryId: cateogryId,
                    customerId: customerId,
                    price: price,
                    quantity: quantity
                },
                success: function(response) {
                    getCartCount(customerId);
                    alert(response);
                }
            });
        }

    </script>

</body>

</html>
