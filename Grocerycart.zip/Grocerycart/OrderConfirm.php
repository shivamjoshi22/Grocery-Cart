<!doctype html>
<?php 
    include_once 'product.php' ;
    if(isset($_POST['confirm'])){
        if(array_key_exists('confirm', $_POST)) { 
            setorder($con);
        }
    }
    
    function getCartData($con){
        $customerId = $_SESSION['id'];
        $sqlQuery = "select c.cartid,c.pid,c.quantity,c.price as cartprice,p.productname,p.imgfile,p.price as price from cart c inner join productmst p on c.pid = p.productid where customerId =".$customerId;
        $result = $con->query($sqlQuery);

        if($result->num_rows > 0){
            $arrData = array();
            while($row = $result->fetch_assoc()){
                $arrData [] = $row;
            }

            if(is_array($arrData) && count($arrData) > 0){
                return $arrData;
            }
            else{
                return 0;
            }
        }
    }

    function setorder($con){
        $order_id = 0 ;
        $sqlQuery = "select orderdetailid from orderdetails";
        $result = $con->query($sqlQuery);
        if (mysqli_num_rows($result) == 0) {
            echo( mysqli_error($con));
            $order_id=1;
        }else if (mysqli_num_rows($result) > 0) {
            $sql2="SELECT MAX(orderdetailid) AS max_val from orderdetails";
            $runquery1=mysqli_query($con,$sql2);
            $row = mysqli_fetch_array($runquery1);
            $order_id= $row["max_val"];
            $order_id=$order_id+1;
            echo( mysqli_error($con));
        }

        $arrCartData = getCartData($con);
        if(is_array($arrCartData)){
            foreach ($arrCartData as $key => $row) {
            $sqlQuery = "insert into orderdetails (orderdetailid,productid,qtyordered,price) values (
            ".$order_id.",".$row["pid"].",".$row["quantity"].",".$row["cartprice"].")"; 
            $con->query($sqlQuery);
            //echo "<pre>";print_r($sqlQuery);die;
        }
            $sqlQuery = "insert into ordermst (orderdetails_ID,cid,orderdate) values (
            ".$order_id.",".$_SESSION['id'].",'".date("Y-m-d")."')";  
            $con->query($sqlQuery);
            
            $sqlQuery = "delete from cart where customerId = ".$_SESSION['id'];  
            $con->query($sqlQuery);    
        }
        
    }
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Order confirmed</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
        echo '<script>
            getCartCount('.$_SESSION['id'].')
        </script>';
    ?>
    <center>
        <div></div>
        <table class="table-responsive">
            <thead>
                <tr>
                    <th scope="col"><img src="1OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></th>
                    <th scope="col"><img src="2OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></th>
                    <th scope="col"><img src="3OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row"><img src="4OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></th>
                    <td><img src="5OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></td>
                    <td><img src="6OrderConfirm.jpg" class="img-fluid" width="250" alt="Responsive image"></td>
                </tr>
            </tbody>
        </table>

        <p class="mt-3">Congratulation,Your Order has been placed succesfully.</p>
        <a class="btn btn-primary mb-5" href="home.php" role="button">Continue Shopping</a>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
