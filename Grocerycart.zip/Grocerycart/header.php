<?php

include_once 'connection.php';
$sql = "select Categoryname from Categorymst";

$result = $con->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $Data [] = $row;
    }
}

echo 
    '<header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top color">
            <h4 class="navbar-brand">Grocery Cart</h4>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <form class="form-inline mt-2 mt-md-0" method="post" action="Productlist.php">
                    <input class="form-control mr-sm-2" id="search" type="text" name="search" placeholder="Search for Product" aria-label="Search">
                    <button class="btn btn-outline-light my-2 my-sm-0" name="searchButton" type="submit">Search</button>
                </form>
            </div>
            <div style="margin-right:20px" id="login">
                <a href="login.php"><button id="loginbutton" type="button" class="btn btn-outline-light">
                        Login
                    </button></a>
            </div>
            <div style="margin-right:100px" id="signup">
                <a href="signupform.php"><button id="loginbutton" type="button" class="btn btn-outline-light">
                        Sign Up
                    </button></a>
            </div>';
            if (isset($_SESSION['firstname'])){
                echo ' <div style="margin-right:20px" id="username">
                    <span id="name" class="text-light text-uppercase font-weight-bold">
                            Hello , '.$_SESSION["firstname"].'
                    </span>
                </div>
                <div style="margin-right:100px" id="logout" onclick="signout()">
                    <a href="logout.php"><button id="logout" type="button" class="btn btn-outline-light">
                            Log out
                        </button></a>
                </div> ';   
            }
        echo '
            <div">
                <a class="navbar-brand" href="addtocart.php">
                    <i class="fa fa-cart-plus" style="color:white"></i>
                    Cart<span id="productCount" class="badge badge-light" style="display:none;"></span>
                </a>
            </div>
        </nav>
    </header>

        <ul class="nav nav-fill navcolor" style="margin-top:16px;">
             <li class="nav-item hvr-icon-fade" >
                <a class="hvr-underline-from-center" href="home.php">Home</a>
            </li>
           
            <li class="nav-item dropright">
                <a class="hvr-underline-from-center dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Shop By Category
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    ';
                    foreach ($Data as $key => $Row){
                        $string = $Row['Categoryname'];
                        $replace = str_replace("and"," and ", $string);
                        $phpfile = strtolower(str_replace(' ', '', $string));
                        echo '<a class="dropdown-item" href="'.$phpfile.'.php">'.ucwords($replace).'</a>
                        <div class="dropdown-divider"></div>';
                    };
                    echo '
                </div>
            </li>
            <li class="nav-item">
                <a class="hvr-underline-from-center" href="YourOrders.php">Orders</a>
            </li>
            <li class="nav-item hvr-icon-fade" >
                <a class="hvr-underline-from-center" href="Statistics.php">Statistics</a>
            </li>
            <li class="nav-item">
                <a class="hvr-underline-from-center" href="offers.php">Offers</a>
            </li>
            <li class="nav-item">
                <a class="hvr-underline-from-center" href="AboutUs.php">About us</a>
            </li>
            <li class="nav-item">
                <a class="hvr-underline-from-center" href="FAQs.php">FAQs</a>
            </li>
        </ul>
    ';
    if(isset($_SESSION['firstname'] ))
    {
        echo '<script type="text/JavaScript">  
                document.getElementById("login").style.display="none";
                document.getElementById("signup").style.display="none";
                document.getElementById("username").style.display="block";
                document.getElementById("logout").style.display="block";
                
                function signout(){
                ';
            echo '
                document.getElementById("login").style.display="block";
                document.getElementById("signup").style.display="block";
                document.getElementById("username").style.display="none";
                document.getElementById("logout").style.display="none";
                }
              </script>';
    }
?>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous">   
</script>
<script type="text/javascript">
    function getCartCount(customerId){
        $.ajax({
                    url: 'commonAjax.php?action=GETCARTCOUNT',
                    type: 'POST',
                    data: {
                        customerId : customerId
                    },
                    success:function(response){
                       $("#productCount").show();
                       $("#productCount").text(response);
                   }
               });
    }

</script>