<!doctype html>
<?php 
    session_start();
    
    include_once 'connection.php';

    if($con != false){
        $arrCartData = getCartData($con);
        //echo "<pre>";print_r($arrCartData);die;
    }
    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }
    function getCartData($con){
        if(isset($_SESSION['id'])){

            $customerId = $_SESSION['id'];
            $sqlQuery = "SELECT cart.cartid, productmst.productid, productmst.productname,productmst.price, productmst.imgfile 
                ,cart.quantity 
                FROM cart
                    inner join productmst
                on cart.pid = productmst.productid
                    where cart.customerId =".$customerId;
            $result = $con->query($sqlQuery);

            if($result->num_rows > 0){
                $arrProductData = array();
                while($row = $result->fetch_assoc()){
                    $arrProductData [] = $row;
                }

                if(is_array($arrProductData) && count($arrProductData) > 0){
                    return $arrProductData;
                }
                else{
                    return 0;
                }
            }
        }
        else{
            $sqlQuery = "select cartid from cart";
            $result = $con->query($sqlQuery);
            if($result->num_rows > 0){
                $_SESSION['count'] = $result->num_rows;
                header("location:login.php");       
            }
        }
    }
        
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Add to cart</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .jumbotron {
            background-image: url("grocery.jpg");
            background-repeat: no-repeat;
            background-size: cover;

        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
        <?php include 'header.php'; 
            echo '
            <script>
                getCartCount('.$IdOfCustomer.')
            </script>';
        ?> 
            
                    <?php
                        if(is_array($arrCartData)){
                            if(count($arrCartData)>0){
                                $intTotal = 0;
                                $counter = 0;
                                $num = -1;
                                $productsId = array();
                                echo'<div class="container d-flex justify-content-center" style="margin-top:20px">
        
                                    <table id="cartTable" class="table table-bordered table-responsive" width=100%>
                                        <thead>
                                            <tr>
                                                <th scope="col" width="300">Image </th>
                                                <th scope="col" width="300">Product name</th>
                                                <th scope="col" width="300">Quantity</th>
                                                <th scope="col" width="300">Amount</th>
                                                <th scope="col" width="300"></th>
                                            </tr>
                                        </thead>
                                    ';
                                $cartArray = array();
                                $i=0;
                                foreach ($arrCartData as $key => $arrOneRowData) {
                                    $num = $num +1 ;
                                    $itemQunatity = 1;
                                    $ip = 0;
                                    $image_src = "images/".$arrOneRowData["imgfile"];
                                    $pid=$arrOneRowData["productid"];
                                    $productsId[$counter++] = $arrOneRowData["productid"];
                                    
                                    $cartArray[$i++] = $arrOneRowData["cartid"];
                                    if ($arrOneRowData["quantity"] > 1 ){
                                        $itemQunatity = $arrOneRowData["quantity"];
                                        $ip = $arrOneRowData["price"] * $itemQunatity ;
                                        $intTotal = $intTotal + $ip;
                                    }else{
                                        $itemQunatity = 1;
                                        $ip = $arrOneRowData["price"];
                                        $intTotal = $intTotal + $arrOneRowData["price"];
                                    }
                                    echo '
                                        <tbody>
                                        <tr>
                                            <th scope="row"><center><img src="'.$image_src.'" class="img-fluid" alt="Responsive image" width="70" height="70"></center></th>
                                            <td>'.$arrOneRowData["productname"].'</td>
                                            <td><input type="number" name="quant" id="quantity_'.$key.'" min="1" max="100" step="1" value="'.$itemQunatity.'" onchange="getPriceByQnty(this, '.$arrOneRowData["price"].', '.$key.');"></td>
                                            <td id="price_'.$key.'">'.$ip.' </td>
                                            <td><center><i class="fas fa-trash" onclick="deleteItemFromCart('.$arrOneRowData["cartid"].', '.$_SESSION["id"].','.$num.','.$arrOneRowData["productid"].');"></i></center></td>
                                        </tr>
                                    '
                                    ;
                                }
                                $str = base64_encode(serialize($productsId));
                                $string = base64_encode(serialize($cartArray));
                                echo '<input type="hidden" id="IdOfProduct" value="'.$str.'">';
                                echo '<input type="hidden" id="IdOfCart" value="'.$string.'">';
                                echo '
                                    <tr>
                                        <td  style="text-align:right;" colspan="4">Total amount</td>
                                        <td><center>Rs.<span id="finalTotalAmount">'.$intTotal.'</span></center></td>
                                        <input type="hidden" id="firstTotalAmount" value="'.$intTotal.'" />
                                    </tr>

                                    </tbody>
                                </table>
                                </div>
                                <center>
                                    <a href="home.php" id="backToShopping">
                                        <button type="button" class="btn btn-outline-primary btn-lg" style="margin-right: 720px">< Back to Shopping</button>
                                    </a>
                                        <button type="button" class="btn btn-outline-primary btn-lg" onclick="itemsUpdate('.$_SESSION["id"].');">Proceed to Checkout ></button>
                                </center>
                                ';
                            }
                        }
                        else{
                            echo"<div id='emptydiv'>
                                 <img src='CartEmpty.png' alt='empty cart'>
                                    <h2 id='CartEmpty'>Your cart is empty.</h2>
                                 <a href='home.php' id='backToShopping'>
                                        <button type='button' class='btn btn-outline-primary btn-lg'>< Back to Shopping</button>
                                </a>
                                 </div>
                                 ";
                        }
                        
                    ?>
                    <input type="hidden" id="quantityOfItems" value="">
                    <input type="hidden" id="amountOfProducts" value="">
       
    </main>
    <footer class="container" id="Footer">
        <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
    </footer>
    <script
              src="https://code.jquery.com/jquery-3.4.1.min.js"
              integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
              crossorigin="anonymous">
    </script>
    <script src="https://kit.fontawesome.com/611a6300eb.js" crossorigin="anonymous"></script>
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
    <script type="text/javascript">
        getCartCount(<?php echo $_SESSION['id']; ?>);
        var items = [];
        var key = 0;

        var cnt = parseInt($("#productCount").text());
        var qunatityOfProducts = [];
        for (var i = 0; i < cnt; i++) {
            items[i] = $("#price_"+key).text();
            qunatityOfProducts[i] = $("#quantity_"+key).val();
            key = key + 1 ;
        }
        $('#quantityOfItems').val(JSON.stringify(items));

        var str = $('#quantityOfItems').val();
        str = JSON.parse(str);

        $('#amountOfProducts').val(JSON.stringify(qunatityOfProducts));

        var strr = $('#amountOfProducts').val();
        strr = JSON.parse(strr);

        function getPriceByQnty(obj,orignialPrice,id){
            var intQnty = $(obj).val();
            var itemPrice = 0; 
            var intTotal = parseInt($("#finalTotalAmount").text());
            var changedPrice = parseInt($("#price_"+id).text());

            itemPrice = intQnty * orignialPrice;
            intTotal = intTotal + itemPrice - changedPrice;

            $("#price_"+id).text(itemPrice);

            $("#finalTotalAmount").text(intTotal);
            key = 0;
            for (var i = 0; i < cnt; i++) {
                items[i] = $("#price_"+key).text();
                qunatityOfProducts[i] = $("#quantity_"+key).val();
                key = key + 1 ;
            }
            $('#quantityOfItems').val(JSON.stringify(items));
                str = $('#quantityOfItems').val();
                str = JSON.parse(str);

            $('#amountOfProducts').val(JSON.stringify(qunatityOfProducts));
                strr = $('#amountOfProducts').val();
                strr = JSON.parse(strr);
            }

            
            function deleteItemFromCart(cartId, customerId , no, pid){
           
           $.ajax({
                url: 'commonAjax.php?action=DELETEFROMCART&Amount='+str+'&id='+customerId+'&Product='+no+'&ProductID='+$("#IdOfProduct").val()+'&OneID='+pid+'&QUANT='+strr+'',
                    type: 'POST',
                    data: {
                        cartId : cartId
                    },
                    success:function(response){
                        getCartCount(customerId);
                        if(response == 1){
                            alert('Item removed from cart successfully.');
                            location.reload(true);
                        }
                        else{
                           alert(response); 
                        }   
                   }
               }); 
            }

            function itemsUpdate(customerId){
                $.ajax({
                url: 'commonAjax.php?action=UPDATECART&Amount='+str+'&id='+customerId+'&ProductID='+$("#IdOfProduct").val()+'&QUANT='+strr+'',
                    type: 'POST',
                    data: {
                        cartId : $("#IdOfCart").val()
                    },
                    success:function(response){
                        getCartCount(customerId);
                        if(response == 1){
                            window.location.replace("PaymentDetails.php");
                        }
                        else{
                           alert(response); 
                        }   
                   }
               });   
            }

    </script>
</body>

</html>
