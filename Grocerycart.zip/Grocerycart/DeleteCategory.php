<!doctype html>
<?php

include_once 'connection.php';
$sql = "select * from Categorymst";

$result = $con->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $Data [] = $row;
    }
}
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Delete Category</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .jumbotron {
            background-image: url("grocery.jpg");
            background-repeat: no-repeat;
            background-size: cover;

        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'adminheader.php'; ?>
    <main role="main">
        <div class="row mt-3">
            <div class="list-group col-2">
                <a href="BackAdd.php" class="list-group-item list-group-item-action">Add Product</a>
                <a href="BackUpdate.php" class="list-group-item list-group-item-action">Update Product</a>
                <a href="BackDelete.php" class="list-group-item list-group-item-action">Delete Product</a>
                <a href="addcategory.php" class="list-group-item list-group-item-action">Add Category</a>
                <a href="UpdateCategory.php" class="list-group-item list-group-item-action">Update Category</a>
                <a href="DeleteCategory.php" class="list-group-item list-group-item-action">Delete Category</a>
                <a href="DeleteUser.php" class="list-group-item list-group-item-action">Delete User</a>
            </div>
            <div class="col-10">
                <div class="container mt-5">
                    <form method="post" action="database.php"> 
                        <select name="deleteSelectCategory" class="custom-select col-3 mb-2">
                        <option selected>Choose category</option>
                        <?php 
                            $counter=1;
                            foreach ($Data as $key => $Row){
                                echo '<option value="'.$Row['categoryid'].'">'.$Row['categoryname'].'</option>';
                            }; 
                        ?>
                        </select>
                        <br>
                        <button type="submit" class="btn btn-primary mb-5 col-3">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <center>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
</body>

</html>
