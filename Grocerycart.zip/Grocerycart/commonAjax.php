<?php

	session_start();

    include_once 'connection.php';

    if(isset($_REQUEST)){
        if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'ADDTOCART'){
            $intProductId = $_REQUEST['productId'];
            $intCategoryId = $_REQUEST['categoryId'];
            $intCustomerId = $_REQUEST['customerId'];
            $intPrice = $_REQUEST['price'];
            $intQunatity = $_REQUEST['quantity'];

            if($intProductId != '' && $intCategoryId!= ''){

            	$check=mysqli_query($con,"select * from cart where pid= ".$intProductId." and cid=".$intCategoryId." and customerid=".$intCustomerId);
			    $checkrows=mysqli_num_rows($check);

			   	if($checkrows>0) {
			    	  echo "Product has been added already.";
			   	} else { 
	            	$strquery = "insert into cart(pid, cid, customerid,quantity,price)
					values(".$intProductId.", ".$intCategoryId.", ".$intCustomerId.",".$intQunatity.",".$intPrice.")
	            	";

					if ($con->query($strquery) === TRUE) {
					    $last_id = $con->insert_id;
					    echo "Product added to cart successfully.";
					} else {
					    echo "Error: " . $strquery . "<br>" . $con->error;
					}
				}
            }

            exit;
        }
        if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'GETCARTCOUNT'){
            $intCustomerId = $_REQUEST['customerId'];

            if($intCustomerId != ''){
            	$check=mysqli_query($con,"select * from cart where customerid=".$intCustomerId);
			    $checkrows=mysqli_num_rows($check);
			    echo $checkrows;
            }
        }
        if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'DELETEFROMCART' && isset($_REQUEST['Amount']) && isset($_REQUEST['id']) && isset($_REQUEST['Product']) && isset($_REQUEST['ProductID']) && isset($_REQUEST['OneID']) && isset($_REQUEST['QUANT'])){
            $intCartId = $_REQUEST['cartId'];
            $str = $_REQUEST['Amount'];

            $intCustomerId = $_REQUEST['id'];
            $arr = array();
            $arr = explode(',', $str);
            
            $quan = array();
            $quan = explode(',', $_REQUEST['QUANT']);

            $pro = array();
            $pro = unserialize(base64_decode($_REQUEST['ProductID']));
            if($_REQUEST['Product'] != ''){
            	$sql="delete from cart where cartid=".$intCartId;

                /*if (($key = array_search( $arr[$_REQUEST['Product']],$arr)) !== false) {
                    unset($arr[$key]);
                }*/

                /*if (($key = array_search( $pro[$_REQUEST['OneID']],$pro)) !== false) {
                    unset($pro[$key]);
                }*/
                //echo "<pre>";print_r($arr);die;           
				if ($con->query($sql) === TRUE) {
                    $count = 0;
                    foreach ($arr as $key => $data) {
                        $sql = 'update cart set price = '.$data.',quantity = '.$quan[$count].' where customerid='.$intCustomerId.' and pid='.$pro[$count]; 
                        $con->query($sql);         
                        $count = $count + 1;
                    }  
				    echo 1;
				} else {
				    echo "Error deleting record: " . $con->error;
				}
            }
        }
        if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'RELOAD'){
            $intCustomerId = $_REQUEST['customerId'];

            if($intCustomerId != ''){
                $check=mysqli_query($con,"select * from cart where customerid=".$intCustomerId);
                $checkrows=mysqli_num_rows($check);
                echo $checkrows;
            }
        }

        if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'UPDATECART' && isset($_REQUEST['Amount']) && isset($_REQUEST['id']) && isset($_REQUEST['ProductID']) && isset($_REQUEST['QUANT'])){

            $CartId = array();    
            $str = $_REQUEST['Amount'];

            $intCustomerId = $_REQUEST['id'];
            $arr = array();
            $arr = explode(',', $str);
            
            $quan = array();
            $quan = explode(',', $_REQUEST['QUANT']);

            $pro = array();
            $pro = unserialize(base64_decode($_REQUEST['ProductID']));
                
            $CartId = unserialize(base64_decode($_REQUEST['cartId']));

            $count = 0;
            foreach ($arr as $key => $data) {
                $sql = 'update cart set price = '.$data.',quantity = '.$quan[$count].' where customerid='.$intCustomerId.' and pid='.$pro[$count] and 'cartid='.$CartId[$count];
                $con->query($sql);  
                $count = $count + 1;
            }
            echo 1;
        }
    }
    exit;
?>