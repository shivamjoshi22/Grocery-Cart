<!doctype html>
<?php 
    include_once 'product.php' ;
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Admin Home</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

        .jumbotron {
            background-color: white;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'adminheader.php'; ?>

    <div class="container mt-2">
        <div class="jumbotron">
            <h1 class="display-4">Welcome, Admin!</h1>
            <p class="lead">These are the all required functions to change the website.</p>
            <hr class="my-4">
            <p>Choose what you are going to do.</p>
            <div class="d-flex justify-content-start">
                <div class="dropdown col-3">
                    <button class="btn btn-primary dropdown-toggle btn-block" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Add
                    </button>
                    <div class="dropdown-menu btn-block" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="addcategory.php">Category</a>
                        <a class="dropdown-item" href="BackAdd.php">Product</a>
                    </div>
                </div>
                <div class="dropdown col-3">
                    <button class="btn btn-primary dropdown-toggle btn-block" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Update
                    </button>
                    <div class="dropdown-menu btn-block" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="UpdateCategory.php">Category</a>
                        <a class="dropdown-item" href="BackUpdate.php">Product</a>
                    </div>
                </div>
                <div class="dropdown col-3">
                    <button class="btn btn-primary dropdown-toggle btn-block" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Delete
                    </button>
                    <div class="dropdown-menu btn-block" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="DeleteCategory.php">Category</a>
                        <a class="dropdown-item" href="BackDelete.php">Product</a>
                    </div>
                </div>
                <a class="btn btn-primary col-3" href="DeleteUser.php" role="button">Delete User</a>
            </div>
        </div>
    </div>

    <center>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
