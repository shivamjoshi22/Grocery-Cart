<!doctype html>
<?php 
    include_once 'product.php' ;
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>About Us</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; ?>
    <div class="container mt-3">
        <h3>About Us :</h3>
        <p class="text-justify">
            What is Grocerycart?<br>
            Grocerycart is online food and grocery store.People spend hundreds of rupees on groceries every month, but don’t have a great understanding of how much they’re actually consuming and in what quantities. Our website would allow users to feed data about their purchases and the system would give them statistics, help plan their grocery.<br>
            <br>
            Why should I use Grocerycart?<br>
            Customer can preorder during festival and occasion. website can notify customer regarding the availability of items ordered.No more getting stuck in traffic jams, paying for parking, standing in long queues and carrying heavy bags
            Users would browse items from the site and add them to their grocery list.The agent then pick up the groceries on the list and make the delivery.<br>
            <br>
            Where do we operate?<br>
            We currently offer our services in Rajkot only.
        </p>
    </div>
    <center>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
