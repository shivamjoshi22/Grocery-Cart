<?php 
    session_start();

    include_once 'connection.php';
    
    if($con != false){
        $arrProductData = getProductsData($con);
    }
    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }
    
    function getProductsData($con){
        
        if(isset($_REQUEST['searchButton'])){
			$name = $_POST['search'];
			$sqlQuery = "select * from productmst where productname like '%".$name."%'";
			$result = $con->query($sqlQuery);
        	
        	if($result->num_rows > 0){
            $arrProductData = array();

            while($row = $result->fetch_assoc()){
                $arrProductData [] = $row;
            }
   
            if(is_array($arrProductData) && count($arrProductData) > 0){
                return $arrProductData;
            }
            else{
                return 0;
            }
        }
		}
    }    
?>
<!doctype html>

<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Dairy Products</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }
 		#Empty{
          margin-top: 60px
        }

        #emptydiv{
          text-align: center;
        }
        .footer{
        	margin: 0 auto;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
    	echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>'; 
    ?>
    <div class="container justify-content-center mt-1">
            	<?php
            	
            	if(isset($_REQUEST['searchButton'])){
                    if(is_array($arrProductData)){
                        if(count($arrProductData)>0){
 							echo '<table class="table table-flexible table-bordered">
						            <thead>
						                <tr>
						                    <th scope="col" width="300"><center>Image</center></th>
						                    <th scope="col" width="380"><center>Product name</center></th>
						                    <th scope="col" width="200"><center>Rate</center></th>
						                    <th scope="col" width="200"></th>
						                </tr>
						            </thead>
						            <tbody>
						        ';
                            foreach ($arrProductData as $key => $arrOneRowData) {
                                $image_src = "images/".$arrOneRowData["imgfile"];
                                $pid=$arrOneRowData["productid"];
                                $cid=$arrOneRowData["categoryid"];
                                echo '
                                     <tr>
                                        <th scope="row"><center><img src="'.$image_src.'" class="img-fluid" alt="Responsive image" width="80" height="70"></center></th>
                                        <td>'.$arrOneRowData["productname"].'</td>
                                        <td><center>Rs.'.$arrOneRowData["price"].'</center></td>
                                        <td><a href="ProductDescription.php?pid='.$pid.'&cid='.$cid.'"><center>Product Details</center></a></td>
                                    </tr>
                                '
                                ;
                            }
                        }
                }
            }
            else{
                	echo"<div id='emptydiv'>
                         <h2 id='Empty'>Please search the Product.</h2>
                         <a href='home.php' id='backToShopping'>
                                <button type='button' class='btn btn-outline-primary btn-lg'>< Back to Shopping</button>
                         </a>
                         </div>
                         ";
                }
                ?>
            </tbody>
        </table>
    </div>

    <center>
        <footer class="container footer">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
