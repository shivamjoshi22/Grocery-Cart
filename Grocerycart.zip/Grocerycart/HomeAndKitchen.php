<!doctype html>
<?php 
    include_once 'product.php' ;
    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Home and Kitchen</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row{
            width: 100%;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>';
    ?>    
    <section>
            <div class="row">
                <div class="col-2">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <th scope="col "><a href="HouseHold.php" style="color:black">House hold</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="HomeAndKitchen.php" style="color:black">Home and Kitchen</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="ReadyToEat.php" style="color:black">Ready to eat</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="Beverages.php" style="color:black">Beverages</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="dairyproducts.php" style="color:black">Dairy Products</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="healthcare.php" style="color:black">Healthcare</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="Personalcare.php" style="color:black">Personal Care</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="babyandkids.php" style="color:black">Baby & Kids</a></th>
                            </tr>
                            <tr>
                                <th scope="row"><a href="Petcare.php" style="color:black">Pet care</a></th>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="col-10">
                    <div class="d-flex justify-content-around flex-wrap">
                        <?php
                            if($arrProductData != 0){
                                foreach ($arrProductData as $key => $arrOneRowData){
                                    $image_src = "images/".$arrOneRowData["imgfile"];
                                    $pid=$arrOneRowData["productid"];
                                    $cid=$arrOneRowData["categoryid"];
                                    $price=$arrOneRowData["price"];
                                    echo '
                                        <div class="card m-3 shadow" style="width: 18rem;">
                                            <a href="ProductDescription.php?pid='.$pid.'&cid='.$cid.'" ><img src="'.$image_src.'" class="card-img-top" style="width:270px;height:200px" alt="'.$arrOneRowData["imgname"].'">
                                            <div class="card-body" style="height:188px">
                                                <h5 class="card-title">'.$arrOneRowData["productname"].'</h5>
                                                <p class="card-text">Rs '.$arrOneRowData["price"].'</p>
                                                <p class="card-text">'.$arrOneRowData["qty"].'</p>
                                            </div>
                                            </a>
                                            <a href="#" class="btn btn-primary" onclick="addToCart('.$pid.','.$cid.','.$IdOfCustomer.','.$price.',1)" >Add to cart</a>
                                        </div>';
                                }
                            }
                            else
                            {
                                echo '<h2>Coming soon...</h2>';
                            }
                        ?>
                    </div>
                </div>
            </div>
        </section>

        <footer class="container">
            <p class="float-right"><a href="#">Back to top</a></p>
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>



    <script
      src="https://code.jquery.com/jquery-3.4.1.min.js"
      integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
      crossorigin="anonymous"> 
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <!--    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>-->
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script type="text/javascript">
        function addToCart(productId, cateogryId, customerId,,price,quantity){
            $.ajax({
                    url: 'commonAjax.php?action=ADDTOCART',
                    type: 'POST',
                    data: {
                        productId : productId,
                        categoryId : cateogryId,
                        customerId : customerId,
                        price : price,
                        quantity : quantity
                    },
                    success:function(response){
                        getCartCount(customerId);
                       alert(response);
                   }
               });
        }
    </script>
    <!--    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>-->

</body>

</html>
