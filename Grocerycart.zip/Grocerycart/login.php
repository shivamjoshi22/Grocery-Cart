<!doctype html>
<?php
include 'connection.php';
    
$emailError='';
$passwordError='';
$message='';
    if(isset($_POST['signin'])){
        $user = $_POST["Email"];
        //$pass = md5($_POST["Password"]);
        $pass = $_POST["Password"];
        if(empty($_POST['Email'])){
            $emailError = "Please Enter Email!";
        }
        else{
            if(!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$_POST['Email'])){
                $emailError = "Please Enter valid email like 'xyz@xyz.com'";
            }
        }

        if(empty($_POST['Password'])){
            $passwordError = "Please Enter Password";
        }
        else{
            if(strlen($pass) < 8)
            {
                $passwordError="Password must have length greater than 8";
            }
        }
        $sql = "SELECT * FROM customermst WHERE email='$user' and password='$pass'";
        
        $result = mysqli_query($con,$sql);
        $item = mysqli_num_rows($result);
    if( $item > 0)
    {   
        while($row = mysqli_fetch_assoc($result))
        {
            $id = $row["cid"];
            $firstname = $row["fname"];
            session_start();
            $_SESSION['id'] = $id;
            $_SESSION['firstname']=$firstname;

            if(isset($_SESSION['count'])){
                $sql = "update cart set customerId = ".$id;
                mysqli_query($con,$sql);
            }
            header("location:home.php");
        }
    }else{
        $message="Invalid Credentials";
    }
}

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Login to Grocery Cart</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
<meta name="theme-color" content="#563d7c">
<link   rel="stylesheet" 
        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" 
        crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
        crossorigin="anonymous">
</script>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    #highlighted {
          position: relative;
        }
    #highlighted .container-fluid h1, 
    #highlighted .container-fluid p {
        color: #fff;
        }
    #highlighted .container-fluid h1 {
          font-size: 54px;
          font-family: Verlag,museo-sans,'Helvetica Neue',Helvetica,Arial,sans-serif;
          color: #414141;
          font-weight: 300;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="floating-lables.css" rel="stylesheet">
  </head>
  <body>
<form class="form-signin" name="login" method="post">
        <div class="text-center mb-4">
        <img class="mb-4" src="grocerycart.PNG" alt="grocery cart" width="348" height="118">
        <h1 class="h3 mb-3 font-weight-normal">Login to Grocery Cart</h1>
      </div>

      <div class="form-label-group">
        <input type="email" name="Email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputEmail">Email address</label>
        <span class="text-danger"><?php echo $emailError ; ?></span>
      </div>

      <div class="form-label-group">
        <input type="password" name="Password" id="inputPassword" class="form-control" placeholder="Password" required>
        <label for="inputPassword">Password</label>
        <span class="text-danger"><?php echo $passwordError ; ?></span>
        <span class="text-danger"><?php echo $message ; ?></span>
      </div>
    <div class="row">
        <div class="form-group col-md-5">
              <div class="checkbox mb-3">
                <label>
                  <input type="checkbox" value="remember-me"> Remember me
                </label>
              </div>
        </div>
        <div class="form-group col-md-7">
            <div id="highlighted" class="hl-basic hidden-xs">
              <div class="container-fluid">
                  <div style="padding-left:40px">
                      <h6><a href="#"> <u>Forgot Password?</u> </a> </h6>
                  </div>
              </div>
            </div>
        </div>
        </div>
      <button name="signin" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
      <center><br>or<br>
    	<p><a href="signupform.php">New Member? Register Here</a></p></center>
    </form>
        
    </body>
</html>
