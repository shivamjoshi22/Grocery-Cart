<?php
    $server = "localhost";
    $user = "root";
    $pass = "";

    $con = new mysqli($server,$user,$pass);
    mysqli_select_db($con,'grocerycart');
    
    if($con === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
?>