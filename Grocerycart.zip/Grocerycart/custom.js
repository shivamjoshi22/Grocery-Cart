('.carousel').carousel({
    interval: 10000
});