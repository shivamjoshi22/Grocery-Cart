<!doctype html>
    
<?php 
    session_start();

    include_once 'connection.php';

    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }
    if($con != false){
        $arrOrderData = getOrderData($con);
        //echo '<pre>';print_r($arrOrderData);die;
    }

    function getOrderData($con){
        if(isset($_SESSION['id'])){
            $sqlQuery = 'select o.ordernumber,o.orderdetails_ID,o.orderdate,c.address1 from ordermst o inner join customermst c on o.cid=c.cid where c.cid='.$_SESSION['id'] ;
            $result = $con->query($sqlQuery);
            if($result->num_rows > 0){
                $arrOrderData = array();
                while($row = $result->fetch_assoc()){
                    $arrOrderData [] = $row;
                }
                
                if(is_array($arrOrderData) && count($arrOrderData) > 0){
                    return $arrOrderData;
                }
                else{
                    return 0;
                }
            }
        }
    }    
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Orders</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

        .jumbotron {
            background-color: white;
        }
        #OrderEmpty{
          margin-top: 60px
        }

        #emptydiv{
          text-align: center;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>';
    ?>
    <div class="container mt-4">
        <?php 
            if(isset($_SESSION['id'])){
                if(is_array($arrOrderData)){
                    if(count($arrOrderData)>0){
                        echo ' <table class="table table-flexible table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col" width="150">Order ID</th>
                                        <th scope="col" width="250">Order Date</th>
                                        <th scope="col" width="400">Shipping Address</th>
                                        <th></th>
                                    </tr>
                                </thead>
                           ';     
                        foreach ($arrOrderData as $key => $arrOneRowData) {
                            echo '<tbody>
                                <tr>
                                    <th scope="row">'.$arrOneRowData['ordernumber'].'</th>
                                    <td>'.$arrOneRowData['orderdate'].'</td>
                                    <td>'.$arrOneRowData['address1'].'</td>
                                    <td><a href="OrderDetails.php?orderid='.$arrOneRowData['orderdetails_ID'].'"">Order Details</a></td>
                                </tr>
                            </tbody>';
                        }
                        echo'</table>';
                    }
                }
            }
            else{
                echo"<div id='emptydiv'>
                        <h2 id='OrderEmpty'>You have not ordered yet. Go and buy something.</h2>
                     <a href='home.php' id='backToShopping'>
                            <button type='button' class='btn btn-outline-primary btn-lg'>< Back to Shopping</button>
                    </a>
                     </div>
                     ";
            }
        ?>
    </div>
    <center>
        <footer class="container" style="position: absolute; bottom: 0">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
