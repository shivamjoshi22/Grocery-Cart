<!doctype html>
<?php 
    session_start();
    
    include_once 'connection.php';
    $Contact = '' ;
    $address = '';
    if($con != false){
        $arrCartData = getCartData($con);
    }

    if($con != false) {
    	$arrCustomerData = getAddress($con);
//echo "<pre>";print_r($arrCustomerData);die;
    	foreach ($arrCustomerData as $customer) {
			$Contact = $customer['contact'];
			$address = $customer['address1'];
		}
    }
    function getCartData($con){
        $customerId = $_SESSION['id'];
        $sqlQuery = "select c.cartid,c.pid,c.quantity,c.price as cartprice,p.productname,p.imgfile,p.price as price from cart c inner join productmst p on c.pid = p.productid where customerId =".$customerId;
        $result = $con->query($sqlQuery);

        if($result->num_rows > 0){
            $arrData = array();
            while($row = $result->fetch_assoc()){
                $arrData [] = $row;
            }

            if(is_array($arrData) && count($arrData) > 0){
                return $arrData;
            }
            else{
                return 0;
            }
        }
    }
       
   	function getAddress($con){
   		$customerId = $_SESSION['id'];
   		$sqlQuery = "select address1,contact from customermst where cid = ".$customerId;
   		$result = $con->query($sqlQuery);

        if($result->num_rows > 0){
            $arrData = array();
            while($row = $result->fetch_assoc()){
                $arrData [] = $row;
            }

            if(is_array($arrData) && count($arrData) > 0){
                return $arrData;
            }
            else{
                return 0;
            }
        }	
   	} 
  
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Payment Details</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .jumbotron {
            background-image: url("grocery.jpg");
            background-repeat: no-repeat;
            background-size: cover;

        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .my-span {
            background-color: white;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php 
    	include 'header.php';
    	echo '<script>
            getCartCount('.$_SESSION['id'].')
        </script>';
    ?>
        <div class="container justify-content-center">
            <table class="table table-flexible table-bordered">
                <thead>
                    <tr>
                    	<th scope="col" width="300"><center>Images</center></th>
                        <th scope="col" width="300"><center>Product name</center></th>
                        <th scope="col" width="300"><center>Quantity</center></th>
                        <th scope="col" width="300"><center>Rate</center></th>
                        <th scope="col" width="300"><center>Total Amount</center></th>
                    </tr>
                </thead>
                <tbody>
                <?php
                        if(is_array($arrCartData)){
                            if(count($arrCartData)>0){
                            	$intTotal = 0;
                                $counter = 0;
                            	foreach ($arrCartData as $key => $arrOneRowData) {
                                    $productsId[$counter++] = $arrOneRowData["pid"];
                                    $intTotal = $intTotal + $arrOneRowData["cartprice"];
                                    $image_src = "images/".$arrOneRowData["imgfile"];
                                    echo '
                                         <tr>
                                         	<th scope="row"><center><img src="'.$image_src.'" class="img-fluid" alt="Responsive image" width="70" height="70"></center></th>
                                            <td>'.$arrOneRowData["productname"].'</td>
                                            <td><center>'.$arrOneRowData["quantity"].'</center></td>
                                            <td><center>'.$arrOneRowData["price"].'</center></td>
                                            <td id="price_'.$key.'"><center>'.$arrOneRowData["cartprice"].' </center></td>
                                        </tr>
                                    '
                                    ;
                                }
                            }
                        }

                    echo '<tr>
                        <td align="right" colspan="4">Total amount to be paid :</td>
                        <td align="center">Rs.'.$intTotal.'</td>
                    </tr>';
                ?>    
                </tbody>
            </table>
        </div>
		
        <div class="container">
        	<div class="form-group">
        		<label for="usr">Contact No. :</label><br>
        		<input type="text" class="form-control" style="width: 200px" value=<?php echo $Contact ?> >
        	</div>
            <div class="form-group">
                <label for="usr">Delivery Address :</label>
                <textarea class="form-control col-5" aria-label="With textarea"><?php echo $address ?></textarea>
            </div>
            Forgot something Go back and get it now<br>
            <a href="home.php"><button type="button" class="btn btn-primary mt-2 mb-2">Continue Shopping</button><br><br>
            </a>
        	
            <div class="border col-6">
                <div>
                    <h4 class="mb-3">Payment</h4>
                    <div class="d-block my-3">
                        <div class="custom-control custom-radio">
                            <input id="cod" name="paymentMethod" checked="" type="radio" class="custom-control-input" required="">
                            <label class="custom-control-label" for="cod">Cash on Delivery</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" required="">
                            <label class="custom-control-label" for="credit">Credit card</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required="">
                            <label class="custom-control-label" for="debit">Debit card</label>
                        </div>
                    </div>
                    <div  id="hidediv" style="display: none;">
	                    <div class="row">
	                        <div class="col-md-6 mb-3">
	                            <label for="cc-name">Name on card</label>
	                            <input type="text" class="form-control" id="cc-name" placeholder="" required="">
	                            <small class="text-muted">Full name as displayed on card</small>
	                            <div class="invalid-feedback">
	                                Name on card is required
	                            </div>
	                        </div>
	                        <div class="col-md-6 mb-3">
	                            <label for="cc-number">Credit card number</label>
	                            <input type="text" class="form-control" id="cc-number" placeholder="" required="">
	                            <div class="invalid-feedback">
	                                Credit card number is required
	                            </div>
	                        </div>
	                    </div>
	                    <div class="row">
	                        <div class="col-md-3 mb-3">
	                            <label for="cc-expiration">Expiration</label>
	                            <input type="text" class="form-control" id="cc-expiration" placeholder="" required="">
	                            <div class="invalid-feedback">
	                                Expiration date required
	                            </div>
	                        </div>
	                        <div class="col-md-3 mb-3">
	                            <label for="cc-cvv">CVV</label>
	                            <input type="password" class="form-control" id="cc-cvv" placeholder="" required="">
	                            <div class="invalid-feedback">
	                                Security code required
	                            </div>
	                        </div>
	                    </div>
                	</div>
                    <hr class="mb-4">
                </div>
                <center><form method="POST" action="OrderConfirm.php"><button name="confirm" class="btn btn-primary btn-md mb-5" type="submit" style="width:150px"> Confirm </button></form></center>
            </div><br>
        <center>Thank you for shopping on our website. Wish you a Happy day, Please visit again.</center>
        </div>
        <hr>

        <footer class="container">
            <p class="float-right"><a href="#">Back to top</a></p>
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </main>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://kit.fontawesome.com/611a6300eb.js" crossorigin="anonymous"></script>
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')
	</script>
    
    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
		$('#cod').click(function() {
		   if($('#cod').is(':checked')) { $('#hidediv').hide(); }
		});
		$('#credit').click(function() {
		   if($('#credit').is(':checked')) { $('#hidediv').show(); }
		});
		$('#debit').click(function() {
		   if($('#debit').is(':checked')) { $('#hidediv').show(); }
		});
    </script>
</body>

</html>
