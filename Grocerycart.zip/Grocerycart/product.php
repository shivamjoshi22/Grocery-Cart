<?php 
    session_start();

    include_once 'connection.php';

    if($con != false){
        $arrProductData = getProductsData($con);
    }


    function getProductsData($con){
        
        $filename = basename($_SERVER['PHP_SELF']);
        $category_name =substr($filename,0,strlen($filename)-4);
        $sqlQuery = 'select * from productmst p inner join categorymst c on p.categoryid = c.categoryid and c.categoryname ="'.$category_name.'"';
        $result = $con->query($sqlQuery);
        if($result->num_rows > 0){
            $arrProductData = array();
            while($row = $result->fetch_assoc()){
                $arrProductData [] = $row;
            }
            //echo '<pre>';print_r($arrHouseHoldData);die;

            if(is_array($arrProductData) && count($arrProductData) > 0){
                return $arrProductData;
            }
            else{
                return 0;
            }
        }
    }    
?>