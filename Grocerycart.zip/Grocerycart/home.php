<!doctype html>
<?php 
    session_start();
    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }

    include_once 'connection.php';

    if($con != false){
        $arrProductData = getProductsData($con);    
        //echo '<pre>';print_r($arrProductData);die;
    }

    function getProductsData($con){
        $sqlQuery = 'select * from productmst p inner join orderdetails o on p.productid = o.productid order by o.qtyordered desc limit 8';
        $result = $con->query($sqlQuery);
        if($result->num_rows > 0){
            $arrProductData = array();
            while($row = $result->fetch_assoc()){
                $arrProductData [] = $row;
            }
       
            if(is_array($arrProductData) && count($arrProductData) > 0){
                return $arrProductData;
            }
            else{
                return 0;
            }
        }
    }
?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Home Page</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet"> 
    <style>
        .jumbotron {
            background-image: url("grocery.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        
        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }   
    
    </style>
    <!-- Custom styles for this template -->
    <link href="custome.css" rel="stylesheet">
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php';
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>';
    ?>
        <div class="jumbotron">
            <center>
                <h1 class="display-4 text-white">Welcome to Grocery Cart</h1>
                <h2 class="display-4 text-white">Order grocery online</h2>
            </center>
        </div>
        
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="margin-top: -30px;">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                    <a href="#"><img src="images/Big1.jpg" class="d-block w-100" alt=""></a>
                </div>
                <div class="carousel-item">
                    <a href="#"><img src="images/Big2.jpg" class="d-block w-100" alt=""></a>
                </div>
                <div class="carousel-item">
                    <a href="#"><img src="images/Big3.jpg" class="d-block w-100" alt=""></a>
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
        </div>

        <div style="margin-top: -30px">
            <div id="title">Featured Products</div>
            <div class="card-group Card-Top-space" id="Card-Left-Space" >
                <div class="card" id="Right-Space">
                    <a href="healthcare.php"><img src="images/f1.jpg" height="300" class="card-img-top" alt=""></a>
                </div>
                <div class="card" id="Right-Space">
                    <a href="readytoeat.php"><img src="images/f2.jpg" height="300" class="card-img-top" alt=""></a>
                </div>
                <div class="personalcare.php" id="Right-Space">
                    <a href="Personalcare.php"><img src="images/f3.webp" height="300" class="card-img-top" alt=""></a>
                </div>
            </div>
        </div>            
        <div class="mt-2" id="title">Trending Items</div>
        <div class="col-10" style="margin-left: 100px">
            <div class="d-flex justify-content-around flex-wrap">
                <?php
                    if($arrProductData != 0){
                        foreach ($arrProductData as $key => $arrOneRowData){
                            $image_src = "images/".$arrOneRowData["imgfile"];
                            $pid=$arrOneRowData["productid"];
                            $cid=$arrOneRowData["categoryid"];
                            $price=$arrOneRowData["price"];
                            echo '<div class="col-md-3">
                                <div class="card" style="width: 18rem;">
                                    <a href="ProductDescription.php?pid='.$pid.'&cid='.$cid.'" ><center><img src="'.$image_src.'" class="card-img-top" style="width:100px;height:100px" alt="'.$arrOneRowData["imgname"].'"></center>
                                    <div class="card-body" style="height:px">
                                        <h5 class="card-title"><center>'.$arrOneRowData["productname"].'</center></h5>
                                        <p class="card-text"><center>Rs '.$arrOneRowData["price"].'</center></p>
                                        <p class="card-text"><center>'.$arrOneRowData["qty"].'</center></p>
                                    </div>
                                    </a>
                                </div>
                            </div>';
                        }
                    }
                ?>
            </div>
     </div>

        <div class="container marketing">

            <!-- START THE FEATURETTES -->
            <hr class="featurette-divider">

            <div class="row featurette">
                <div class="col-md-9">
                    <p class="lead" style="margin-top:90px">"Online shopping from a great selection at Grocery and Gourmet Foods Store. We provide daily essentials."</p>
                </div>
                <div class="col-md-3">
                    <img src="images/Daily-Essentials.jpg" width="300px" height="300px">
                </div>
            </div>

            <hr class="featurette-divider">

            <div class="row featurette">
                <div class="col-md-7 order-md-2">
                    <p class="lead" style="margin-top:90px">"We provide variety of Different Indian Spices."</p>
                </div>
                <div class="col-md-5 order-md-1">
                    <img src="images/Indiangrocery.jpg" width="300px" height="300px">
                </div>
            </div>

            <hr class="featurette-divider">

            <div class="row featurette">
                <div class="col-md-9">
                    <p class="lead" style="margin-top:90px">“Writing is a job, a talent, but it's also the place to go in your head. It is the imaginary friend you drink your tea with in the afternoon. A cup of tea makes everything better."</p>
                </div>
                <div class="col-md-3">
                    <img src="images/Fine-Teas.jpg" width="300px" height="300px">
                </div>
            </div>

            <hr class="featurette-divider">

        </div>


        <!-- FOOTER -->
        
     <footer id="myFooter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 myCols">
                    <h5>Get started</h5>
                    <ul>
                        <li><a href="home.php">Home</a></li>
                        <li><a href="signupform.php">Sign up</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 myCols">
                    <h5>About us</h5>
                    <ul>
                        <li><a href="ContactUs.php">Contact us</a></li>
                        <li><a href="AboutUs.php">Copany Information</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 myCols">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="FAQs.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 myCols">
                    <h5>Legal</h5>
                    <ul>
                        <li><a href="Privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="social-networks">
            <a href="https://twitter.com/login" class="twitter"><i class="fa fa-twitter"></i></a>
            <a href="https://en-gb.facebook.com/login/" class="facebook"><i class="fa fa-facebook-official"></i></a>
            <a href="https://accounts.google.com/" class="google"><i class="fa fa-google-plus"></i></a>
        </div>
        <div class="footer-copyright">
            <p class="float-right"><a href="home.php">Back to top</a></p>  
            <p> &copy; 2020 Grocery Cart</p>
        </div>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>

</body>

</html>