<?php

    
    $FirstnameError='';
    $LastnameError='';
    $EmailError='';
    $PasswordError='';
    $CPasswordError='';
    $MobileError='';
    $AddressError='';
    $Address2Error='';
    $boolean= true;
        
    include 'connection.php';

    if(isset($_POST['Submit'])){
        
        $firstname=$_POST['firstname'];
        $lastname=$_POST['lastname'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $address=$_POST['address'];
        $address2=$_POST['address2'];
        $mobile=$_POST['mobile'];
        $cPassword=$_POST['cpassword'];        
        
        if(empty($firstname)){
            $FirstnameError = "Name is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^[a-zA-Z ]{2,30}$/",$_POST['firstname'])){
                $FirstnameError = "Enter valid Name";
                $boolean = false;
            }
        }
        
        if(empty($lastname)){
            $LastnameError = "Name is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^[a-zA-Z ]{2,30}$/",$_POST['lastname'])){
                $LastnameError = "Enter valid Name";
                $boolean = false;
            }
        }

        if(empty($email)){
            $EmailError = "Email is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$_POST['email'])){
                $EmailError = "Enter valid email Like 'abc@abc.com";
                $boolean = false;
            }
        }
        
        if(empty($password)){
            $PasswordError = "Password is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^(?=.*[\d])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])[\w!@#$%^&*]{8,}$/",$_POST['password'])){
                $PasswordError = "Passwords must be At least 8 characters long,Include at least 1 lowercase,1 capital letter,1 number, 1 special character";
                $boolean = false;
            }
        }

        if(empty($cPassword)){
            $CPasswordError = "Please Confirm the Password!";
            $boolean = false;
        }
        else{
            if(strcmp($_POST["password"],$_POST['cpassword'])!=0){
                $CPasswordError = "Enter same password";
                $boolean = false;
            }
        }

        if(empty($mobile)){
            $MobileError = "Mobile no. is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^\+[0-9]{12}$/",$_POST['mobile'])){
                $MobileError = "Enter valid Mobile Number with country code like +91";
                $boolean = false;
            }
        }
        
        if(empty($address)){
            $AddressError = "Address is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^[a-zA-Z0-9'\.\-\s\,]{2,30}$/",$_POST['address'])){
                $AddressError = "Enter valid Address";
                $boolean = false;
            }
        }
        
        if(!empty($address2)){
            if(!preg_match("/^[a-zA-Z0-9'\.\-\s\,]{2,30}$/",$_POST['address2'])){
                $Address2Error = "Enter valid Address";
                $boolean = false;
            }
        }
                
        if(empty($mobile)){
            $MobileError = "Mobile no. is required!";
            $boolean = false;
        }
        else{
            if(!preg_match("/^\+[0-9]{12}$/",$_POST['mobile'])){
                $MobileError = "Enter valid Mobile Number with country code like +91";
                $boolean = false;
            }
        }
        if ($boolean)
        {
            //$password=md5($password);
            $sql = "INSERT INTO customermst (email,password,contact,address1,address2,fname, lname ) VALUES
            ('$email','$password','$mobile','$address','$address2','$firstname','$lastname')";
            if(mysqli_query($con, $sql)){
                header('location: login.php');
            } 
            else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
            }
        }

        // Close connection
        mysqli_close($con);

    }
?>
<!doctype html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Sign Up</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <style>
        form
          {
            margin-left:35%; 
            margin-bottom:20px
          }
      </style>
        
  </head>
  <body>
      <form style="width:900px" method="post" enctype="multipart/form-data">
          <div class="text-center col-md-5">
            <img class="mb-4" src="grocerycart.PNG" alt="grocery cart" width="348" height="118">
            <h1 class="h3 mb-3 font-weight-normal" style="padding-bottom:10px">Registration Form</h1>
          </div>
                    <div class="form-group col-md-5">
                        <label for="inputEmail4">First Name <span style="color:red">*</span></label>
                        <input type="text" name="firstname" class="form-control" placeholder="Enter your First name" required>
                    </div>    
                <span  style="padding-left:20px" class="text-danger form-inline"><?php echo $FirstnameError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputEmail4">Last Name <span style="color:red">*</span></label>
                        <input type="text" name="lastname" class="form-control" placeholder="Enter your Last name" required>
                    </div>
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $LastnameError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputEmail4">Email <span style="color:red">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
                    </div>        
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $EmailError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputPassword4">Password <span style="color:red">*</span></label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                    </div>
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $PasswordError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputPassword4">Confirm Password <span style="color:red">*</span></label>
                        <input type="password" name="cpassword" class="form-control" placeholder="Please confirm password" required>
                    </div>
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $CPasswordError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputAddress">Mobile number <span style="color:red">*</span></label>
                        <input type="text" name="mobile" class="form-control" placeholder="Enter your mobile number" required>
                    </div>
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $MobileError; ?></span>
                    <div class="form-group col-md-5">
                        <label for="inputAddress">Address <span style="color:red">*</span></label>
                        <input type="text" name="address" class="form-control" placeholder="Enter your primary address" required>
                    </div>
                <span style="padding-left:20px" class="text-danger form-inline"><?php echo $AddressError; ?></span>
                <div class="form-group col-md-5">
                        <label for="inputAddress2">Address 2</label>
                        <input type="text" name="address2" class="form-control" placeholder="Enter your secondary address">
                    </div>
                    <div class="form-group">
                        <div class="form-check" style="margin-left:15px">
                            <input class="form-check-input" type="checkbox" id="gridCheck">
                            <label class="form-check-label" for="gridCheck">
                                Remember me
                            </label>
                        </div>
                    </div>
          <button type="submit" name='Submit' class="btn btn-primary" style="margin-left:15px" >Register</button>
        <br>
     <div style="margin-left:15px;margin-top:5px">Are you existing user? <a href="login.php">Click here to login</a></div>
    </form >
  </body>
</html>