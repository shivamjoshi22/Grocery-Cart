<!doctype html>

<?php 
    include_once 'connection.php';
    session_start();
    
    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }

    if($con != false){
        if(isset($_SESSION['id'])){
                $arrData = getData($con);
            $arrCategoryData = getCategoryData($con);
            
            $arrCatData = array();
            $counter = 0;

            foreach ($arrCategoryData as $key => $row) {
                $arrCatData[$counter++] = $row["categoryname"];
            }

            $arrPriceData = array();
            $arrDupCat = array();
            $counter = 0;

            $arrDataPrice = array();
            foreach ($arrData as $key => $row) {
                $arrPriceData[$counter] = $row["price"];
                $arrDupCat[$counter] = $row["categoryname"];
                $counter = $counter + 1;
            }    

            $count = 0;
            for ($i=0; $i < sizeof($arrCatData) ; $i++) { 
                if($count < sizeof($arrDupCat) && in_array($arrDupCat[$count], $arrCatData) ){
                    $pos=array_search($arrDupCat[$count],$arrCatData);
                    $var=$arrCatData[$pos];
                    $arrCatData[$pos]=$arrCatData[$count];
                    $arrCatData[$count]=$var;
                    $count = $count +1;
                }
            }
        }
    }

    function getData($con){
        if(isset($_SESSION['id'])){

            $sqlQuery = "select c.categoryname,sum(o.price) as price from categorymst c inner join productmst p on c.categoryid=p.categoryid inner join orderdetails o on o.productid = p.productid inner join ordermst om on om.orderdetails_ID=o.orderdetailid inner join customermst cs on cs.cid=om.cid where cs.cid = ".$_SESSION['id']." GROUP by c.categoryid,c.categoryname";
        
            $result = $con->query($sqlQuery);
            if($result->num_rows > 0){
                $arrData = array();
                while($row = $result->fetch_assoc()){
                    $arrData [] = $row;
                }
                
                if(is_array($arrData) && count($arrData) > 0){
                    return $arrData;
                }
                else{
                    return 0;
                }
            }
        }
    }    

/*    if($con != false){
        $arrCategoryData = getCategoryData($con);
        $arrCatData = array();
        $counter = 0;

        foreach ($arrCategoryData as $key => $row) {
            $arrCatData[$counter++] = $row["categoryname"];
        }

    }*/

    function getCategoryData($con){
        
        $sqlQuery = "select categoryname from categorymst";
        
        $result = $con->query($sqlQuery);
        if($result->num_rows > 0){
            $arrCategoryData = array();
            while($row = $result->fetch_assoc()){
                $arrCategoryData [] = $row;
            }
            
            if(is_array($arrCategoryData) && count($arrCategoryData) > 0){
                return $arrCategoryData;
            }
            else{
                return 0;
            }
        }
    }

    
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Statistics</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

        .text {
            color: dodgerblue;
        }
        
        .graph {
            display: block;
            height: 400px;
            width: 600px;
        }
         #OrderEmpty{
          margin-top: 60px
        }

        #emptydiv{
          text-align: center;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; 
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>';
    ?>
    
    <h2 class="d-flex justify-content-center text" >Purchase Statistics</h2>
    <?php 
        if(!isset($_SESSION['id'])){
            echo"<div id='emptydiv'>
                <h2 id='OrderEmpty'>Please login to see your Purchase Statistics.</h2>
             <a href='home.php' id='backToShopping'>
                    <button type='button' class='btn btn-outline-primary btn-lg'>< Back to Shopping</button>
            </a>
             </div>
             ";
        }else{
            echo'<center>
                    <div style="width: 1000px; height: 500px;">
                        <canvas id="bar-chart" class="chartjs-render-monitor graph"></canvas>
                    </div>
                </center>
            ';
        }
    ?>
    <center class="container mt-5">
        <footer class="container" style="position: relative;bottom: 0">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>

    <script type="text/javascript">

        var jArray= <?php echo json_encode($arrCatData ); ?>;
        var jPriceArray= <?php echo json_encode($arrPriceData ); ?>;
        // Bar chart
         
        new Chart(document.getElementById("bar-chart"), {
            type: 'bar',
            data: {
              labels: jArray,
              datasets: [
                {
                  label: "Purchase (thousands)",
                  backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850",'rgba(255, 159, 64, 0.4)', 'rgba(250, 250, 89, 0.4)','rgba(75, 192, 192, 0.2)'],
                  data: jPriceArray
                }
              ]
            },
            options: {
              legend: { display: false },
              title: {
                display: true,
                text: 'Orders Statistics for Purchase'
              }
            }
        });

    </script>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
