<?php

include_once 'connection.php';

echo 
    '<header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top color">
            <h4 class="navbar-brand" style="margin-left:550px">Grocery Cart</h4>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </nav>
    </header>
    ';
?>