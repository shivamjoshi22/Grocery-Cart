<!doctype html>
<?php 
    session_start();
    
    include_once 'connection.php';

    $IdOfCustomer = 0 ;

    if(isset($_SESSION['id'])){
        $IdOfCustomer = $_SESSION['id'];
    }

    if($con != false){
        $arrProductData = getProductsData($con);
    }

    function getProductsData($con){
        $pid=$_GET['pid'];
        $cid=$_GET['cid'];
        $filename = basename($_SERVER['PHP_SELF']);
        $category_name =substr($filename,0,strlen($filename)-4);
        $sqlQuery = 'select * from productmst where productid = '.$pid.' and categoryid = '.$cid.'';
        $result = $con->query($sqlQuery);
        if($result->num_rows > 0){
            $arrProductData = array();
            while($row = $result->fetch_assoc()){
                $arrProductData [] = $row;
            }
            //echo '<pre>';print_r($arrHouseHoldData);die;

            if(is_array($arrProductData) && count($arrProductData) > 0){
                return $arrProductData;
            }
            else{
                return 0;
            }
        }
    }    
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Product derscription</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .jumbotron {
            background-image: url("grocery.jpg");
            background-repeat: no-repeat;
            background-size: cover;

        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .my-img {
            border: 1px solid gray;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php';
        echo '
        <script>
            getCartCount('.$IdOfCustomer.')
        </script>'; 
     ?>
    <section>
        <div class="row">
            <div class="col-2">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th scope="col "><a href="HouseHold.php" style="color:black">House hold</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="HomeAndKitchen.php" style="color:black">Home and Kitchen</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="ReadyToEat.php" style="color:black">Ready to eat</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="Beverages.php" style="color:black">Beverages</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="dairyproducts.php" style="color:black">Dairy Products</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="healthcare.php" style="color:black">Heatlhcare</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="Personalcare.php" style="color:black">Personal Care</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="babyandkids.php" style="color:black">Baby & Kids</a></th>
                        </tr>
                        <tr>
                            <th scope="row"><a href="Petcare.php" style="color:black">Pet care</a></th>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="col-10">
                <div class="d-flex justify-content-start mt-3">
                    <?php
                            if($arrProductData != 0){
                                foreach ($arrProductData as $key => $arrOneRowData){
                                    $image_src = "images/".$arrOneRowData["imgfile"];
                                    $pid=$arrOneRowData["productid"];
                                    $cid=$arrOneRowData["categoryid"];
                                    echo '
                                    <input type="hidden" id="productId" value="'.$pid.'" />
                                    <input type="hidden" id="categoryId" value="'.$cid.'" />
                                    <input type="hidden" id="customerId" value="'.$IdOfCustomer.'" />
                                    <input type="hidden" id="price" value="'.$arrOneRowData['price'].'" />
                                    <img src="'.$image_src.'" class="img-fluid" alt="Responsive image" width="400" height="400">
                                    <div class="container mt-5 ml-5">
                                        <div class="row">
                                            <div class="col">
                                                '.$arrOneRowData["productname"].'
                                            </div>
                                        </div>
                                        <div class="row mt-1">
                                            <div class="col font-weight-bold">
                                                MRP : Rs '.$arrOneRowData["price"].'
                                            </div>
                                        </div>
                                        <div class="row mt-1">
                                            <div class="col">
                                                '.$arrOneRowData["qty"].'
                                            </div>
                                        </div>
                                        <div class="row mt-1">
                                            <div class="col">
                                                <button type="button" class="btn btn-primary" id="addToCart">Add to cart</button>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="container mt-4">
                                        <div class="row">
                                            <div class="col font-weight-bold">
                                                About the Product
                                            </div>
                                        </div>
                                        <div class="row mt-2 mb-2">
                                            <div class="col">
                                                <p class="text-justify">
                                                    '.$arrOneRowData["description"].'
                                                </p>
                                            </div>
                                        </div>
                                    </div>';
                                }
                            }
                        ?>
                </div>
            </div>
        </div>
    </section>
    <center>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>



    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous">
    </script>
    <script>
        window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')

    </script>
    <script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#addToCart").click(function() {
                $.ajax({
                    url: 'commonAjax.php?action=ADDTOCART',
                    type: 'POST',
                    data: {
                        quantity: 1,
                        price: $("#price").val(),
                        productId: $("#productId").val(),
                        categoryId: $("#categoryId").val(),
                        customerId: $("#customerId").val()
                    },
                    success: function(response) {
                        getCartCount($("#customerId").val());
                        alert(response);
                    }
                });
            });
        });

    </script>
</body>

</html>
