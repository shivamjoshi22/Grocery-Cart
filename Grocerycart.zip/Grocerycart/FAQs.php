<!doctype html>
<?php 
    include_once 'product.php' ;
?>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>FAQs</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        #search {
            width: 550px;
            margin-left: 100px;
        }

        .row {
            width: 100%;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
</head>

<body>
    <?php include 'header.php'; ?>
    <div class="container mt-3">
        <p class="text-justify">
            Registration related Questions:<br><br>
            
            How do I register?<br>
            You can register by clicking on the "Sign Up" at the homepage. Please provide the information in the form that appears. provide your details and submit the registration information.
            <br><br>
            Do I have to necessarily register to shop on bigbasket?<br>
            You can surf and add products to the cart without registration but only registered shoppers will be able to checkout and place orders. Registered members have to be logged in at the time of checking out the cart, they will be prompted to do so if they are not logged in.<br><br>
            
            Can I have multiple registrations?<br>
            Each email address and contact phone number can only be associated with one Grocerycart account.
            <br><br>
            
            Account Related Questions:
            <br><br>
            What is My Account?<br>
            My Account is the section you reach after you log in at Grocerycart.My Account allows you to track your order history and update your contact and other details.
            <br><br>
            How do I reset my password?<br>
            You need to enter your email address on the Login page and click on forgot password. An email with a reset password will be sent to your email address. With this, you can change your password.
            <br><br>

            Payment realted Questions:
            <br><br>
            What are the modes of payment?<br>
            You can pay for your order on Grocerycart using the Cash On Delivery(cod) option only.We are currently improving our payment modes and will soon add online payments option.
            <br><br>
            What is the meaning of cash on delivery?<br>
            Cash on delivery means that you can pay for your order at the time of order delivery at your doorstep.
            <br><br>
            
            Delivery Realted :
            <br><br>
            When will I receive my order?<br>
            Once you are done selecting your products and click on checkout you will be prompted. choose the payment method and place it.
            <br><br>
            How will the delivery be done?<br>
            We have a team of delivery ensures timely and accurate delivery to our customers.
            <br><br>
            What is the minimum order for Delivery?<br>
            For orders above 1200 Delivery is free. Else we charge a nominal fee of 50 rupees.
            <br><br>

            Order Realted:<br><br>
            
            How do I add or remove products after placing my order?<br>
            Once you have placed your order you will not be able to make modifications on the website. Please contact our team for any modification of order.
            <br><br>
            Is it possible to order an item which is out of stock?<br>
            No you can only order products which are in stock.
            <br><br>
            How do I check the current status of my order?<br>
            The only way you can check the status of your order is by contacting our customer support team.
            <br><br>
            Is there an order cancellation fee?<br>
            No, but you must cancel it befor pick up or else it will charge you delivery fee.
            <br><br>
            How can I cancel an order?<br>
            You can cancel an order before the by contacting our customer support team or you can also cancel your order from the GroceryCart.
            <br><br>
            Customer Related :<br>
            How can I give feedback on the quality of customer service?<br>
            Our customer support team constantly strives to ensure the best shopping experience for all our customers. We would love to hear about your experience with bigbasket. Do write to us grocerycustomersupport@gmail.com in case of positive or negative feedback.
            <br><br>
            Return & Refund<br>
            We have a "no questions asked return and refund policy" which entitles all our members to return the product at the time of delivery if due to some reason they are not satisfied with the quality or freshness of the product. We will take the returned product back with us.
            <br><br>
            Return Policy - Time Limits:<br>
            1. Perishable goods: Within 48 hours from the delivery date<br>
            2. Other goods : Within 7 days from the delivery date<br>
            <br>
            OTHERS:<br><br>
            
            The product I want is not available on bigbasket.<br>
            You can write to sellersupport@gmail.com for all suggestions related to new stores or products. We will work extra hard to get the store listed on bigbasket and get the product available to you.<br>
            <br>
            What do I do if an item is defective (broken, leaking, expired)?<br>
            We have a no questions asked return policy. In case you are not satisfied with a product received you can return it to the delivery personnel at time of delivery or you can contact our customer support team and we will do the needfull.
            <br><br>
            How will I get my money back in case of a cancellation or return? What are the modes of refund?<br>
            The amount will be added your account Please contact customer support for any further assistance regarding this issue.
        </p>
    </div>
    <center>
        <footer class="container">
            <p>&copy; 2020 Grocery Cart &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>
    </center>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
